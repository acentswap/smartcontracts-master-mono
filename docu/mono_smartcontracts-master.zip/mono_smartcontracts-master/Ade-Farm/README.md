# ACENT Farm 💎

## run tests locally
1. `cp .env.example .env`
2. fill in the info in .env file
3. `yarn && yarn compile && yarn test`
