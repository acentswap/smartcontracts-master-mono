# ADE Finance Swap Periphery

## Local Development

The following assumes the use of `node@>=10`.

## Install Dependencies

`yarn install-all`

## Compile Contracts

`yarn compile`

## Run Tests

`yarn test`
