const AcentPair = artifacts.require("AcentPair");

module.exports = function (deployer) {
  deployer.deploy(AcentPair);
};
